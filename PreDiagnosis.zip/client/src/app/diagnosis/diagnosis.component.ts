import { Component, OnInit } from '@angular/core';
import { DataService } from '../service/data.service';
import { DataModel } from '../edit-data/data.model';


@Component({
  selector: 'app-diagnosis',
  templateUrl: './diagnosis.component.html',
  styleUrls: ['./diagnosis.component.css']
})
export class DiagnosisComponent implements OnInit {

  fData:any = {};
  cData:any = {};
  selectedArea: string = '';
  selectedSympi: string = '';
  
  showImage:boolean = false;
  showHead: boolean =false;

  constructor(private dataService: DataService) { }

  // cData = new DataModel(this.selectedValue,this.selectedSympi,null,null,null);

  fSub():void {
    this.showImage = !this.showImage;
  }

  scroll(el: HTMLElement){
    this.showHead = !this.showHead;
    el.scrollIntoView({behavior: "smooth"});
  }

  selectedHeadArea(head: any){this.selectedArea = head.target.value;}
  sHFHead(head:any){this.selectedSympi = head.target.value;}
  sHEye(head:any){this.selectedSympi = head.target.value;}
  sHNose(head:any){this.selectedSympi = head.target.value;}
  sHEar(head:any){this.selectedSympi = head.target.value;}

  checkData(){
    let sympiAt = this.selectedArea;
    let symptom = this.selectedSympi;
    this.dataService.checkData(sympiAt,symptom)
    .subscribe((data)=> {console.log(data);
      this.cData = JSON.parse(JSON.stringify(data));
    });
  }

  ngOnInit(): void {
  }

}
