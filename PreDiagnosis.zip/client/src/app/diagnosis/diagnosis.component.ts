import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-diagnosis',
  templateUrl: './diagnosis.component.html',
  styleUrls: ['./diagnosis.component.css']
})
export class DiagnosisComponent implements OnInit {

  fData:any = {};
  selectedValue: string = '';
  
  showImage:boolean = false;
  showHead: boolean =false;

  constructor() { }

  fSub():void {
    this.showImage = !this.showImage;
  }

  scroll(el: HTMLElement){
    this.showHead = !this.showHead;
    el.scrollIntoView({behavior: "smooth"});
  }

  selectedHeadValue(head: any){
  this.selectedValue = head.target.value;
}

  ngOnInit(): void {
  }

}
