import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-data',
  templateUrl: './edit-data.component.html',
  styleUrls: ['./edit-data.component.css']
})
export class EditDataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
