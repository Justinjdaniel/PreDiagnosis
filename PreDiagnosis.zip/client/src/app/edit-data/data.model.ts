export class DataModel{
    constructor(
        public sympiAt: string,
        public symptom: string,
        public cause: string,
        public recom: string,
        public suggWeb: string
    ){}
}